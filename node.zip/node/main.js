var http= require('http');
var URL= require('url');

var server=http.createServer(function(req,res){

	var myURL="http://rabil.com/blog.html?year=2020&month=july";
	
	myURLObj=URL.parse(myURL,true);
	
	var myHostName=myURLObj.host;
	var myPathName=myURLObj.pathname;
	var mySearchName=myURLObj.search;
	res.writeHead(200,{'content-Type':'Text/html'});
	res.write(myHostName);
	res.end();
	
});
server.listen(5050);
console.log("Server Run Success");