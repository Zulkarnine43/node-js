const express =require('express');
const mysql= require('mysql');

const db=mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : '',
    database: 'my_db'
});

db.connect((err)=>{
    if(err){
        throw err;
    }
        console.log("Mysql Connected");

});

const app=express();

app.get('/createdb',(req,res)=>{
    let sql='CREATE DATABASE my_db';
    db.query(sql,(err,result)=>{
        if(err) throw err;
        console.log(result);
        res.send('Database Created');
    });
});
app.get('/createpoststable',(req,res)=>{
    let sql='CREATE TABLE posts(id int AUTO_INCREMENT,title VARCHAR(255),body VARCHAR(255),PRIMARY KEY id)';
 db.query(sql,(err,result)=>{
     if(err) throw err;
     console.log(result);
     res.send('Posts table created...');
 });
});
//SElect posts
app.get('/addpost1',(req,res)=>{
    let post={title:'post one', body:'this is post number one'};
    let sql='INSERT INTO posts SET ?';
    let query=db.query(sql,post,(err,result)=>{
        if(err) throw err;
        console.log(result);
        res.send('Post 1....');
    });
});
//select single post
app.get('/getpost1',(req,res)=>{
    let sql='SELECT * FROM INTO posts';
    let query=db.query(sql,post,(err,result)=>{
        if(err) throw err;
        console.log(result);
        res.send('Post fetched....');
    });
});
//update posts
app.get('/updatepost/:id',(req,res)=>{
    let sql='UPDATE posts SET title=$(newTitle) WHERE id=${req,params,id'};
    let query=db.query(sql,(err,result)=>{
        if(err) throw err;
        console.log(result);
        res.send('Post updated....');
    });
});
//delete post

app.get('/deletepost/:id',(req,res)=>{
    let sql='Delete FROM posts WHERE id=${req,params,id'};
    let query=db.query(sql,(err,result)=>{
        if(err) throw err;
        console.log(result);
        res.send('Post deleted....');
    });
});




app.listen('4000',()=>{
    console.log('server started on port 4000');

});